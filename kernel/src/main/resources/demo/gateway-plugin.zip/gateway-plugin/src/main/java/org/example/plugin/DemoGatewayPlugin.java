package org.example.plugin;

import cloud.apposs.gateway.GatewayHttpRequest;
import cloud.apposs.gateway.GatewayHttpResponse;
import cloud.apposs.gateway.annotation.CommonPlugin;
import cloud.apposs.gateway.plugin.PluginAdapter;
import cloud.apposs.gateway.plugin.PluginResult;
import cloud.apposs.gateway.route.Route;
import cloud.apposs.gateway.zone.Zone;
import cloud.apposs.ioc.annotation.Component;
import cloud.apposs.react.React;

@Component
@CommonPlugin
public class DemoGatewayPlugin extends PluginAdapter {
    public static final String NAME = "DemoGatewayPlugin";

    public DemoGatewayPlugin() {
        super(NAME);
        System.out.println("DemoGatewayPlugin " + NAME + " Initialize");
    }

    @Override
    public React<PluginResult> preFilter(GatewayHttpRequest request, GatewayHttpResponse response, Zone zone, Route route) throws Exception {
        System.out.println("DemoGatewayPlugin preFilter Invoke");
        return React.just(PluginResult.SUCCESS);
    }
}
